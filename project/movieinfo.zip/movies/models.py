from django.db import models
from django.dispatch import receiver
import os

# Create your models here.
class Movie(models.Model):
    mcode = models.AutoField(primary_key=True)
    mname = models.CharField('',max_length=100)
    mdirector = models.CharField('',max_length=50)
    mnation = models.CharField('',max_length=50)
    mgenre = models.CharField('',max_length=100)
    mactor = models.CharField('',max_length=100)
    mopen = models.DateField('',auto_now=False)
    msynopsis = models.CharField('',max_length=2000,blank=True)
    mposter = models.ImageField('',upload_to='images/',blank=True)

@receiver(models.signals.pre_save, sender=Movie)
def update_file_delete(sender, instance, **kwargs):
    if not instance.mcode:
        return False
    try:
        old_obj = sender.objects.get(mcode=instance.mcode)
    except sender.DoesNotExist:
        return False

    for field in instance._meta.fields:
        field_type = field.get_internal_type()
        if field_type == 'FileField' or field_type == 'ImageField':
            ori_file = getattr(old_obj, field.name)
            new_file = getattr(instance, field.name)
            #print(ori_file, new_file)
            if ori_file and ori_file != new_file and os.path.isfile(ori_file.path):
                os.remove(ori_file.path)

@receiver(models.signals.post_delete, sender=Movie)
def file_delete(sender, instance, **kwargs):
    for field in instance._meta.fields:
        field_type = field.get_internal_type()
        if field_type == 'FileField' or field_type == 'ImageField':
            ori_file = getattr(instance, field.name)
            if ori_file and os.path.isfile(ori_file.path):
                os.remove(ori_file.path)