from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('write', views.write, name='write'),
    path('detail/<int:mcode>', views.detail, name='detail'),
    path('delete/<int:mcode>', views.delete, name='delete'),
    path('update/<int:mcode>', views.update, name='update'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
