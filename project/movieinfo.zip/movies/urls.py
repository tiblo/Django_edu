from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('write', views.write, name='write'),
    path('detail/<int:mcode>', views.detail, name='detail'),
    path('update/<int:mcode>', views.update, name='update'),
    # 삭제 url 작성
    path('download', views.download, name='download'),
]
