from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse
from django.template import loader
from .models import Movie
from .form import MovieForm
from django.core.paginator import Paginator

# Create your views here.
def index(request):
    page = request.GET.get("page", 1)
    movie_list = Movie.objects.all().order_by('-mcode').values()
    paginator = Paginator(movie_list, 5)
    movies = paginator.get_page(page)
    template = loader.get_template('index.html')
    context = {
        'movies': movies,
    }
    return HttpResponse(template.render(context, request))

def write(request):
    if request.method == 'POST':
        movieForm = MovieForm(request.POST)
        if movieForm.is_valid():
            movie = movieForm.save(commit=False)
            movie.mposter = request.FILES.get('mposter', None)
            movie.save()
            return redirect('index')
    else:
        movieForm = MovieForm()
        template = loader.get_template('writeForm.html')
        context = {
            'form': movieForm,
        }
    return HttpResponse(template.render(context, request))

def detail(request, mcode):
    movie = Movie.objects.get(mcode=mcode)
    template = loader.get_template('detail.html')
    context = {
        'movie': movie,
    }
    return HttpResponse(template.render(context, request))


def delete(request, mcode):
    movie = get_object_or_404(Movie, mcode=mcode)
    movie.delete()
    return redirect('index')

def update(request, mcode):
    movie = get_object_or_404(Movie, mcode=mcode)
    if request.method == 'POST':
        movie_form = MovieForm(request.POST, instance=movie)
        if movie_form.is_valid():
            movie = movie_form.save(commit=False)
            poster = request.FILES.get('mposter', None)
            if poster != None:
                movie.mposter = poster
            movie.save()
            return redirect('/detail/' + str(mcode))
    else:
        movie_form = MovieForm(instance=movie)
        template = loader.get_template('updateForm.html')
        context = {
            'form': movie_form,
            'poster': movie.mposter,
        }
    return HttpResponse(template.render(context, request))