from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('write', views.write, name='write'),
    path('detail/<int:mcode>', views.detail, name='detail'),
    path('delete/<int:mcode>', views.delete, name='delete'),
    path('update/<int:mcode>', views.update, name='update'),
    path('download', views.download, name='download'),
]
