from django.forms import *
from .models import Movie

class MovieForm(ModelForm):
    class Meta:
        model = Movie
        fields = '__all__'
        widgets = {
            'mname': TextInput(attrs={
                'class': 'write-input',
                'placeholder': '제목',
            }),
            'mdirector': TextInput(attrs={
                'class': 'write-input',
                'placeholder': '감독',
            }),
            'mnation': TextInput(attrs={
                'class': 'write-input',
                'placeholder': '국가',
            }),
            'mgenre': TextInput(attrs={
                'class': 'write-input',
                'placeholder': '장르',
            }),
            'mactor': TextInput(attrs={
                'class': 'write-input',
                'placeholder': '주연배우',
            }),
            'mopen': DateInput(attrs={
                'type': 'date',
                'class': 'write-input',
            }),
            'msynopsis': Textarea(attrs={
                'class': 'write-input ta',
                'placeholder': '영화 개요',
            }),
            'mposter': FileInput(attrs={
                'id': 'file',
                'style': 'display: none'
            }),
        }
        

